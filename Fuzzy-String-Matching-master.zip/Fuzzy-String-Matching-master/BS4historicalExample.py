# -*- coding: utf-8 -*-
"""
Spyder Editor

"""
html = """

<html>
<body>
<p><b>19391106</b></p>
<p><i>
Kirje:                                                                                                                          SAK/41/1 
Kankaanrää  6.11.1939. 
Rakas   A,Uveja   Reijo. 
Niin   täällä  ollaan  perillä.  Eilen   illalla  klo  10.30  saavuimme.   Jyväs-
kylässä  oli  4  t.  odotusaikaa,   joten  ennätti   tutustua  hiukan   kaupunkiin. 
Söimme   eräässä  kemiassa   ravintolassa  päivällisen  å13:-.   Täällä  on   vain 
al iupseereja  ja  upseereja.   Kummatkin   muissa  komppanioissa.   Minusta   lei-
vottiin  tavallinen  ryhmän   johtaja  3:aan  upseerikomppaniaan.   Täällä  on 
upseereja  ainakin  4  komppaniaa.   Tuttujadkin  paljon  joukossa  m.m.    Ilmari   V. 
y.m.   Täällä  on   komeat   uudet   kasarmit  keskuslämmityksineen.   Valtava 
ruokasali   ja  aika  hyvä   ruoka.   Sitäpaitsi  on   sotilaskoti,  elokuvat 
(parhaillaan  esitetään:"Punaisen  neil ikan   paluutta")  Tässä  alkurytä-
kässä  ei   vielä  tiedä,  minkälaiseksi   muuttuu   tämä   koulutusohjelma.   En 
luulisi  sen  muodostuvan  erikoisen  raskaaksi.   Hiukan   tässä  pyrkii   väsyt-
tämään,   sillä  viime  yönäkään  ei   tullut  paljon  nukutuksi,   mutta  ehkä   jo 
ensi   yönä     saa  tarpeekseen.   Herätys  on   kaikilla  klo  kuudelta.   Mitään 
aseita  eikä  varusteita  ei   ole  jaettu,  ainoastaan  vuodevaatteet. 
01  ihan   se  hiukan   ikävä   lähteä  kotoa  näin  kauaksi,   mutta  minkäs   sille 
voi,   kaikkeen   täytyy  tottua.  Toivottavasti  et  Sinä  eikä  Reijo  jääneet 
kovaan   ikävään.   Koittakaa  nyt   tulla  toimeen.   Ajatte] in   tässä  ehdottaa, 
että  matkustaisit  Reijon   kanssa  joksikln  ajaksi   Haminaan   Mummia   ja 
Pappaa   katsomaan,   eikös  se  toisi  hiukan   vaihtelua.   Ehkä   joku  sillä 
aikaa   lämmittäisi   huoneita? 
Tee   nyt  mitä  haluat,  mutta  älä    missaan  nimessä  sure.   Ehkä   pian 
koittaa  paremmat ajat.   Saa   nähdä,   milloin  Sinä  saat  tämän   kirjeen, 
mutta  ehkä   se  joskus  perille  tulee.  Vaikken   saisikaan  sieltä  päin 
vastausta,  niin  kirjoitan  pian  taas  uudelleen. 
Voikaa  nyt  oikein  hyvin   rakkaipani. 
Syd.   terveisin 
Os.   Niinisalo 
3/UP 
Res.    luutn.   S. 
Kenttäpostia 
Oiva. 
//Aune~ 
</i></p>
<p><b>19391109</b></p>
<p><i>
Kirje: 
Kankaanpää  9.11 ,39, 
Rakkaat  /Anne/ja   Reijo. 
SAK/41/2 
Kun   aloitin  tämän   kirjeeni,    en   ollut  saanut  Sinulta  vielä  riviäkään.   Kir-
jeeni  ja  korttini  varmaankaan  eivät  ole  saavuttaneet  S:linnaa  tai  Sinun   kirjee-
si   yhä   vipyy  matkalla.  01  isi  ollut  mielenkiintoista  tietää,  miten  Sinä   Reijon 
kanssa  jaksat.  Ette  suinkaan  vaan  ole   ikävässä.   Olkaa  vain   iloisia  ja  toivo-
rikkaita,  kyllä  me    pian  taas  olemme   kaikki   kolme   yhdessä   ja  silloin  on   hauskaa. 
On    se  merkillistä  miten   rakkaiksi   Te   käytte  päivä  päivältä,  mitä  kauemmin   olen 
Teistä  erossa.  Uskon,   ettette  Tekään  ole  minua   unohtaneet--.  Huomaat,   että 
käytän   saa  Te   ,  mutta  niinhän  minun   on   meneteltävä,  etten  tekisi   Reijolle 
vääryyttä.  Sinä  kuitenkin  yhä  olet  Sinä  -   Anne   ja  minua   välillä  hävettää, 
kun   muistelen,  että  siellä  arkioloissa  en   tarpeeksi   aina  Sinua  huomannut. 
Sinä  kuitenkin  annat  anteeksi   -   ukkomies   on   aina  ukkomies.   Ehkä   onnemme 
on   taas  täydellisempää,   kun   jälleen  olemme   yhdessä.   Minä   luotan  siihen, 
sillä  tällaiset  raskaat  ajat  siloittavat  sopivasti   itsekkäitä  piirteitämme. 
Me    täydell istymme   vain  näiden  pakollisten  eronhetkien  ansiosta. 
Vielä  ei   ole  tietoa,  milloin  täältä  pääsemme.   Puhutaan   kolmesta  viikosta 
jopa  kuudestakin  viikosta,  mutta  puheet  ovat  puheita.   RUK:n   urseerit  ovat 
tulleet  meitä  opettamaan  m.m.   Olssoni,   joten  "vanha  Naakka11      on   jätetty  sure-
maan.   Täällä  ali upseerien  joukossa  on   myös   talonmiehemme   K.,   niin  että 
voit  sanoa  muodol  1 isesti  terveiset  hänen  eukolleen,   jos  viitsit. 
Minä   yhä   suositteleisin,  että  tekisit  Reijon  kanssa  virkistysmatkan  Hami-
naan,   kun   minun   saapumisestani   ei   toistaiseksi  ole  tietoa.  01  isi  Mummista 
ja  Papastakin  varmasti  mieluisaa,  että  kävisit  heitä  tervehtimässä.  Menisit 
ensin  junalla  ~appeenrantaan  ja  siitä  l injurilla  Haminaan.   Pepe-tätiä  kävi-
sitte  tervehtimässä  ja  veisitte  samalle  terveiseni.   Ehkä   voisit  saada 
jonkun  silläaikaa  lämmittämään   huoneita.   Niitä  ei   tarvitsisi  paljon   läm-
mittää.   Ehkä   T:n  Mirjan?  -   Voikaa   taas  hyvin   ja  olkaa  toivorikkaita. 
Sinua  ja  Reijoa  aina   rakastava  ja  muistava  Oiva. 
os.   Niinisalo  3./UP. 
Pane  postimerkki,   niin  tulee  nopeammin. 
</i></p>
<p><b>19391111</b></p>
<p><i>
Kirje: 
Rakas   Anne   ja  Reijo. 
Kankaanpää 
11  . 11  . 39. 
SAK/41/3 
Tuhannet   kiitokset  kirjeestäsi,  jonka  sain  tunti   sitten.  Tuntui   n11n   mukavalta, 
kun   minäkin  sain  kirjeeh.   Tänne   nimittäin  tulee  huimasti   kirjeitä  päivittäin, 
vaan   kylläpä  hi  itä  lähetetäähkin.  Missä  vaan   tilaa  on   oöydillä,  niin  kaiket 
illat  siinä  kirjoitellaan.  Toiset  taas  kuluttavat  aikaansa  kortinoelulla, 
romaanien   ja  ennehkaikkea  lehtien  lukemisella.   Tänne   tulee  joka  ilta  saman-
päivän   pääkaupungin  ja  muidenkin   paikkakuntien   lehtiä.  Pojat  käyvät   niitä 
kaupalla  täällä  kasarmissa.   Ja  ne   menevät   kuin  kuumille  kiville.  Radioita 
täällä  on   myös   joissakih  kämpissä  ja  sitten  on   oma   radio,  jossa  joka   ilta 
klo  9,00  kuullaan   iltahartaus.   Niin,   että  ajan  tasalla  täällä  ollaan.  Toissa 
iltana  kävin  V:n   kanssa  elokuvissa  katsomassa   ranskalaista  elokuvaa  "Hyljätty". 
Se   oli   suuremmoisen  vaikuttava.   Elokuvateatteri  on   myös   aivan  nykyaikainen 
noin  400   istumapaikaa  kaikki   punaisella  sametilla  verhottuja.   Ja  äänikone 
on   aivan  ajanmukainen.   Kylä,   jossa  tämä   teatteri  on,   sijaitsee  aivan   lä  -
hellä  1/2  km:n   päässä  kasarmista.   Se   on   rakennettu  yksinomaan   leirialuetta 
ja  reserviläisten  mukavuutta  varten.   Kaikki   talot  ovat  uusia,   ja  jokaisessa 
on   kahvila,   partureita,  valokuvaamoja  y.m.   Sekatavarakaupat  ovat  aina  21  :een 
saakka  auki.   Siitä  olisi  muutakin   kerrottavaa,  mutta  jääköön  toistaiseksi.  -
Tänä   iltana  olin  ensimmäistä  kertaa  kasarmin  saunassa.   Sekin  on   kerrassaan 
ajanmukainen  ja  valtavan  suuri.  -   Nuo   kaverit  tuossa  ympärillä  juttelevat 
parhaillaan  vallan  mahdottomia,   niin  ettei  jouda  muuta   kuin   nauramaan. 
Täällä  on   kyllä  huumori   huipussaan,   eikä  senvuoksi   ennätä  suremaan.   Nyt 
pitää  keskeyttää  tämä   sepustus   iltahartauden  ajaksi.  -
Ei    ole  toistaiseksi  tarkempaa   tietoa,  kuinka  kauan   tämä   kertausharjoi-
tus  täällä  kestää.   Ohjelma  on   suuhniteltu  ainakin  tämän   kuukauden   ajaksi, 
mutta   tietysti  tämä   saattaa  loppua  piankin,   jos  tilanne  selviää.  Meistä 
koulutetaan  nostoväeh  harjoitusupseereja  sotatilan  varalta.  Minullahan 
on   jo  sijoitus  harj.  jälkeen  sinne  S:l innan  Tyttökoululle  1.   kompp:n 
päälliköksi.   Siitä  taisin  jo  mainita  tänne   lähtiessäni.  Onni in   hyvä 
olla,  kun   tiedän  että  kumpikin   voitte  hyvin.   Se   olisi  hyvä,   jos  Mummi 
tulisi  hetkeksi   sinne  luoksenne   lepäämään,   mutta  ehkä  Sinäkin  voisit 
Reijon   kanssa  käydä  Hamihassa.   -   Täällä  ovat  jotkut  upseereista  saaneet 
kotoaan   paketteja.   Koskahan  minä   saan  sellaisen-?  Ei    suurta.  Siinä  saisi 
olla  villainen  kaulaliina  ja  flanellinen  yöpuku   ja  42   numeron   olkioohj ia 
nenäliinoja  ja  ehkä  -   pari   omenaa   -   karamelleja  -   vaikka  niitä,  joita 
löysin  kapsäkistäni.   Sinä  olet  kultainen  vaimo.   Kumpa   nyt  vain  jaksaisit 
tulla  Reijon  kanssa  toimeen.   Kyllä  minä   puolestani   pärjään.   Olen   jo 
vähitellen  oppinut  hukkumaahkin.   Sitäpaitsi  tänne  tuleekin  nyt   tilavampaa 
ja  ilmavampaa,   kun   tykistöupseerit  siirretään  pois  jonnekin  Tuusulaan 
ja  Pe rkj ä rve 11 e. 
Koska   tämä   kehttäpostikin  näyttää  aika  nopeasti   toimivan,   niin  käytä 
vain  sitä.  Mutta  nopeammin   kyllä  tulee  postimerkin  kanssa.   Tämä   Kankaan-
pää  ei   kuulu  sotatoimialueeseen  ja  senvuoksi   saa  kuoreen  merkitä  Niini-
salon.   Ei    täällä  myöskään   ole  mitään   pimennysharjoituksia,   vaan   sähköt 
palavat  täyttä  päätä.  Voikaa   taas  oikein  hyvin.   Mihä   muistelen  Teitä 
kumpaakin   useih  ja  oleh  ajatuksissa  luonanne  -   Jumala  Teistä  huolehtikoon. 
Oiva. 
Reunamerkintä:   Kirjoita  taas  pian! 
rs 
</i></p>

</body>
</html>
"""
from bs4 import BeautifulSoup
soup = BeautifulSoup(html, 'lxml')
print(soup.prettify())#standard format

print(soup.find_all('b'))#check element b
print(soup.find_all('i'))#check element i
print(type(soup.find_all('i')))

